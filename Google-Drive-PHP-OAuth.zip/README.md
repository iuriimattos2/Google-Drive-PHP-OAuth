# PHP-Firebase-Auth-Sample-Project

```sh
composer require google/apiclient:^2.0
```